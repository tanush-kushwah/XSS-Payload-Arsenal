// XSS Payload Arsenal v2.0
// Author: Tanush Kushwah — https://github.com/tanush-kushwah

const GITHUB_URL = 'https://github.com/tanush-kushwah';
const STORAGE_KEY = 'xss_custom_payloads';

// ── STATE ──
let currentPanel = 'library';
let currentCat = 'all';
let searchQuery = '';
let customPayloads = [];

// ── ELEMENTS ──
const payloadList    = document.getElementById('payloadList');
const searchInput    = document.getElementById('searchInput');
const countDisplay   = document.getElementById('countDisplay');
const customList     = document.getElementById('customList');
const customCount    = document.getElementById('customCount');
const toast          = document.getElementById('toast');

// ── TOAST ──
let toastTimer = null;
function showToast(msg, type = 'success') {
  toast.textContent = msg;
  toast.className = `toast ${type} show`;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { toast.className = 'toast'; }, 2200);
}

// ── ESCAPE HTML ──
function esc(str) {
  return String(str)
    .replace(/&/g,'&amp;').replace(/</g,'&lt;')
    .replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

// ── TAG CLASS ──
function tagClass(tag) {
  const m = { basic:'tag-basic', bypass:'tag-bypass', dom:'tag-dom', advanced:'tag-advanced', poly:'tag-poly', custom:'tag-custom' };
  return m[tag] || 'tag-basic';
}

// ── CLIPBOARD ──
function copyText(text) {
  if (navigator.clipboard) {
    navigator.clipboard.writeText(text).catch(() => fallbackCopy(text));
  } else {
    fallbackCopy(text);
  }
}
function fallbackCopy(text) {
  const el = document.createElement('textarea');
  el.value = text;
  document.body.appendChild(el);
  el.select();
  document.execCommand('copy');
  document.body.removeChild(el);
}

// ── INJECT TO PAGE ──
function injectToPage(code) {
  chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
    if (!tabs[0]) { showToast('⚠ No active tab', 'error'); return; }
    chrome.scripting.executeScript({
      target: { tabId: tabs[0].id },
      func: (payload) => {
        const inputs = document.querySelectorAll(
          'input[type="text"],input[type="search"],input[type="url"],input[type="email"],input:not([type]),textarea'
        );
        let n = 0;
        inputs.forEach(inp => {
          if (inp.offsetParent !== null && !inp.readOnly && !inp.disabled) {
            inp.focus();
            inp.value = payload;
            inp.dispatchEvent(new Event('input', { bubbles: true }));
            inp.dispatchEvent(new Event('change', { bubbles: true }));
            n++;
          }
        });
        return n;
      },
      args: [code]
    }, results => {
      const n = results?.[0]?.result || 0;
      if (chrome.runtime.lastError) {
        showToast('⚠ Cannot inject here', 'error');
      } else if (n > 0) {
        showToast(`⚡ Injected into ${n} field(s)!`, 'info');
      } else {
        showToast('⚠ No input fields found', 'error');
      }
    });
  });
}

// ── RENDER LIBRARY ──
function renderLibrary() {
  const q = searchQuery.toLowerCase();
  const allPayloads = [
    ...XSS_PAYLOADS,
    ...customPayloads.map(p => ({ ...p, isCustom: true }))
  ];

  const filtered = allPayloads.filter(p => {
    const catMatch = currentCat === 'all'
      ? true
      : currentCat === 'custom'
        ? p.isCustom
        : p.cat === currentCat;
    const qMatch = !q || p.name.toLowerCase().includes(q) || p.code.toLowerCase().includes(q) || p.cat.includes(q);
    return catMatch && qMatch;
  });

  countDisplay.textContent = filtered.length;
  payloadList.innerHTML = '';

  if (!filtered.length) {
    payloadList.innerHTML = `<div class="empty-state"><span class="empty-icon">🔍</span>No payloads found<br><small>Try a different search or category</small></div>`;
    return;
  }

  filtered.forEach(p => {
    const div = document.createElement('div');
    div.className = 'payload-item' + (p.isCustom ? ' is-custom' : '');
    div.dataset.code = p.code;

    const tagKey = p.isCustom ? 'custom' : p.tag;
    const descHtml = p.desc ? `<div class="pi-desc">${esc(p.desc)}</div>` : '';
    const delBtn = p.isCustom
      ? `<button class="btn-sm btn-del" data-del="${p.id}">🗑 Delete</button>`
      : '';

    div.innerHTML = `
      <div class="pi-top">
        <span class="pi-name">${esc(p.name)}</span>
        <span class="pi-tag ${tagClass(tagKey)}">${p.isCustom ? 'CUSTOM' : p.tag.toUpperCase()}</span>
      </div>
      ${descHtml}
      <div class="pi-code">${esc(p.code)}</div>
      <div class="pi-actions">
        <button class="btn-sm btn-copy" data-code="${esc(p.code)}">📋 Copy</button>
        <button class="btn-sm btn-inject" data-code="${esc(p.code)}">⚡ Inject</button>
        ${delBtn}
      </div>
    `;
    payloadList.appendChild(div);
  });
}

// ── RENDER CUSTOM LIST (inside Custom tab) ──
function renderCustomList() {
  customCount.textContent = customPayloads.length;
  customList.innerHTML = '';

  if (!customPayloads.length) {
    customList.innerHTML = `<div class="empty-state" style="padding:20px"><span class="empty-icon">📝</span>No custom payloads yet<br><small>Add one above!</small></div>`;
    return;
  }

  customPayloads.forEach(p => {
    const div = document.createElement('div');
    div.className = 'payload-item is-custom';
    const descHtml = p.desc ? `<div class="pi-desc">${esc(p.desc)}</div>` : '';
    div.innerHTML = `
      <div class="pi-top">
        <span class="pi-name">${esc(p.name)}</span>
        <span class="pi-tag tag-custom">CUSTOM · ${esc(p.cat)}</span>
      </div>
      ${descHtml}
      <div class="pi-code">${esc(p.code)}</div>
      <div class="pi-actions">
        <button class="btn-sm btn-copy" data-code="${esc(p.code)}">📋 Copy</button>
        <button class="btn-sm btn-inject" data-code="${esc(p.code)}">⚡ Inject</button>
        <button class="btn-sm btn-del" data-del="${p.id}" style="margin-left:auto">🗑 Delete</button>
      </div>
    `;
    customList.appendChild(div);
  });
}

// ── LOAD / SAVE CUSTOM ──
function loadCustom() {
  chrome.storage.local.get([STORAGE_KEY], res => {
    customPayloads = res[STORAGE_KEY] || [];
    renderCustomList();
    if (currentPanel === 'library') renderLibrary();
  });
}

function saveCustom(cb) {
  chrome.storage.local.set({ [STORAGE_KEY]: customPayloads }, cb);
}

// ── ADD CUSTOM PAYLOAD ──
document.getElementById('btnAdd').addEventListener('click', () => {
  const name = document.getElementById('customName').value.trim();
  const code = document.getElementById('customPayload').value.trim();
  const cat  = document.getElementById('customCat').value;
  const desc = document.getElementById('customDesc').value.trim();

  if (!name) { showToast('⚠ Please enter a payload name', 'error'); return; }
  if (!code) { showToast('⚠ Please enter a payload', 'error'); return; }

  const newP = {
    id: Date.now(),
    name, code, cat, desc,
    tag: 'custom', isCustom: true
  };

  customPayloads.unshift(newP);
  saveCustom(() => {
    renderCustomList();
    renderLibrary();
    document.getElementById('customName').value = '';
    document.getElementById('customPayload').value = '';
    document.getElementById('customDesc').value = '';
    showToast('✓ Payload saved to library!', 'success');
  });
});

// ── CLEAR ALL CUSTOM ──
document.getElementById('btnClearAll').addEventListener('click', () => {
  if (!customPayloads.length) { showToast('Nothing to clear', 'info'); return; }
  if (!confirm(`Delete all ${customPayloads.length} custom payloads?`)) return;
  customPayloads = [];
  saveCustom(() => {
    renderCustomList();
    renderLibrary();
    showToast('✓ All custom payloads cleared', 'info');
  });
});

// ── DELETE ONE ──
function deleteCustom(id) {
  customPayloads = customPayloads.filter(p => p.id !== id);
  saveCustom(() => {
    renderCustomList();
    renderLibrary();
    showToast('✓ Payload deleted', 'info');
  });
}

// ── DELEGATED CLICKS – Library ──
payloadList.addEventListener('click', e => {
  // Delete button
  const del = e.target.closest('[data-del]');
  if (del) { e.stopPropagation(); deleteCustom(Number(del.dataset.del)); return; }

  // Action buttons
  const btn = e.target.closest('.btn-sm');
  if (btn) {
    e.stopPropagation();
    const code = btn.dataset.code;
    if (btn.classList.contains('btn-copy')) {
      copyText(code);
      showToast('✓ Payload copied!', 'success');
    } else if (btn.classList.contains('btn-inject')) {
      injectToPage(code);
    }
    return;
  }

  // Click on item = copy
  const item = e.target.closest('.payload-item');
  if (item) {
    copyText(item.dataset.code);
    item.classList.add('copied');
    setTimeout(() => item.classList.remove('copied'), 1400);
    showToast('✓ Copied to clipboard!', 'success');
  }
});

// ── DELEGATED CLICKS – Custom list ──
customList.addEventListener('click', e => {
  const del = e.target.closest('[data-del]');
  if (del) { e.stopPropagation(); deleteCustom(Number(del.dataset.del)); return; }

  const btn = e.target.closest('.btn-sm');
  if (btn) {
    e.stopPropagation();
    const code = btn.dataset.code;
    if (btn.classList.contains('btn-copy')) {
      copyText(code); showToast('✓ Copied!', 'success');
    } else if (btn.classList.contains('btn-inject')) {
      injectToPage(code);
    }
    return;
  }
  const item = e.target.closest('.payload-item');
  if (item && item.dataset.code) {
    copyText(item.dataset.code);
    showToast('✓ Copied!', 'success');
  }
});

// ── MAIN TABS ──
document.querySelectorAll('.main-tab').forEach(tab => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('.main-tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
    tab.classList.add('active');
    currentPanel = tab.dataset.panel;
    document.getElementById(`panel-${currentPanel}`).classList.add('active');
    if (currentPanel === 'library') renderLibrary();
  });
});

// ── CATEGORY TABS ──
document.getElementById('catTabs').addEventListener('click', e => {
  const tab = e.target.closest('.cat-tab');
  if (!tab) return;
  document.querySelectorAll('.cat-tab').forEach(t => t.classList.remove('active'));
  tab.classList.add('active');
  currentCat = tab.dataset.cat;
  renderLibrary();
});

// ── SEARCH ──
searchInput.addEventListener('input', e => {
  searchQuery = e.target.value;
  renderLibrary();
});

// ── GITHUB BUTTON ──
document.getElementById('githubBtn').addEventListener('click', () => {
  chrome.tabs.create({ url: GITHUB_URL });
});

// ── INIT ──
loadCustom();
renderLibrary();
