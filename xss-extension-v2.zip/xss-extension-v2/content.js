// XSS Payload Arsenal - Content Script
// Listens for injection commands from popup

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'inject') {
    const inputs = document.querySelectorAll(
      'input[type="text"], input[type="search"], input:not([type]), textarea'
    );
    let count = 0;
    inputs.forEach(inp => {
      if (inp.offsetParent !== null) {
        inp.value = request.payload;
        inp.dispatchEvent(new Event('input', { bubbles: true }));
        inp.dispatchEvent(new Event('change', { bubbles: true }));
        count++;
      }
    });
    sendResponse({ injected: count });
  }
});
