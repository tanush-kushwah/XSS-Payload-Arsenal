# ⚡ XSS Payload Arsenal v2.0

> **Author:** Tanush Kushwah  
> **GitHub:** [github.com/tanush-kushwah](https://github.com/tanush-kushwah)

A professional Chrome extension for security researchers and penetration testers — featuring a comprehensive XSS payload library and the ability to save your own custom payloads.

> ⚠️ **For authorized security testing only.**

---

## 📦 Installation

1. Download and extract this folder
2. Open Chrome → go to `chrome://extensions/`
3. Enable **Developer Mode** (toggle, top-right)
4. Click **"Load unpacked"** → select the `xss-extension` folder
5. The ⚡ icon appears in your Chrome toolbar

---

## 🚀 Features

- 📚 **70+ Built-in Payloads** across 6 categories
- 🔍 **Live Search** — filter instantly by name or code
- 📋 **One-Click Copy** — click any payload to copy
- ⚡ **Auto-Inject** — fills all visible inputs on the active page
- ✏️ **Custom Payloads** — add, save, delete your own (persisted!)
- ⭐ **Custom Tab** — view only your saved payloads
- 🔗 **GitHub link** in header

---

## 📂 Categories

| Category | Description |
|----------|-------------|
| Basic | Classic alert-based XSS |
| WAF Bypass | Encoding, mutation, null bytes |
| DOM | innerHTML, location.hash, document.write |
| Advanced | Angular/Vue/React, SVG, exfiltration |
| Polyglot | Multi-context payloads |
| Blind XSS | Out-of-band / delayed XSS |

---

## 👤 Author

**Tanush Kushwah** — [github.com/tanush-kushwah](https://github.com/tanush-kushwah)

---

## ⚖️ Legal

Use only on systems you own or have **explicit written authorization** to test.
